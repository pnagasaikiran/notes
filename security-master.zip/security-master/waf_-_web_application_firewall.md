# WAF - Web application firewall


One of the first things we should do when starting to poke on a website is see what WAF it has.

## Identify the WAF

```
wafw00f http://example.com
```

http://securityidiots.com/Web-Pentest/WAF-Bypass/waf-bypass-guide-part-1.html
