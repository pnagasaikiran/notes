# Tools of the trade

Here is just a collection of some tools that I use that I want to have an easy manual for.