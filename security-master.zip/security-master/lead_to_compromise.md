# Attacking the System

I have divided the web-vulnerabilites into two categories: **Attacking the System** and **Attacking the User**. I know this might seem like a pretty weird categorization, but I think it make sense. So in this chapter we will look at vulnerabilities that primarily focus on the webserver, and not the visiting users.



