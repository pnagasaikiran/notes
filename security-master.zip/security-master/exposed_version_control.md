# Exposed Version Control

If you, using dirb or nikto, find version control file exposed, you can use it like this.

```
git clone http://example.com/.git
```

https://en.internetwache.org/dont-publicly-expose-git-or-how-we-downloaded-your-websites-sourcecode-an-analysis-of-alexas-1m-28-07-2015/
