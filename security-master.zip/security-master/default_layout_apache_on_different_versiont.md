# Default Layout of Apache on Different Versions


Really useful if you want to know what the root-folder is for an apache install:

https://wiki.apache.org/httpd/DistrosDefaultLayout#Debian.2C_Ubuntu_.28Apache_httpd_2.x.29: