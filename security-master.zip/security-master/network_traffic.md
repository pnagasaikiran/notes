# Network traffic

So you have entered a network and it is time to start mapping it. It is probably a good idea to start monitoring the traffic.