# Java applet

Okay this is pretty outdated. Chrome does not support java by default anymore. But other browsers do, and a lot of companies use java.

This is an attack that is based on attacking the user and not necessarily the software. We want the user to execute malicious code on his/her computer. 

