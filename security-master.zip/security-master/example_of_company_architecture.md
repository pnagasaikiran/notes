# Example of company architecture

https://www.reddit.com/r/AskNetsec/comments/4p7onl/gaining_initial_access_in_realworld_pentesting/

![Map](dGaQO6Y.png)