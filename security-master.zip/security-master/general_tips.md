# General tips

## Disposable email

If you are signing up for a lot of accounts you can use a disposable email. You just enter the email account you want for that second, and then you can view it. But remember, so can everyone else.  
[https://www.mailinator.com](https://www.mailinator.com)

## Base64 encode/decode

```python
import base64

encoded = base64.b64encode("String to encode")
print encoded

decoded = base64.b64decode("aGVqc2Fu")
print decoded
```

## Default passwords

[http://www.defaultpassword.com/](http://www.defaultpassword.com/)

## Getting GUI on machine that does not have RDP or VNC

You can forward X over SSH.  
[http://www.vanemery.com/Linux/XoverSSH/X-over-SSH2.html](http://www.vanemery.com/Linux/XoverSSH/X-over-SSH2.html)


