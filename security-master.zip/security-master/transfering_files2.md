# Transferring Files

This section could easily be put in the post-exploitation section. But I consider this knowledge so fundamental that I chose to put it here.


