# Scripting With Python

There are many high-level scripting languages that are easy to use. One really popular one is Python. 


