# Networking

This is just some basics of networking.

## Sockets

BSD Sockets (Berkely Software Distribution)

### Socket API
The socket API exists in most programming languages. It is usually something like this.

Socket - create a new connection endpoint
bind - 
listen
accept 
connect
send
recieve 
close



## References
https://www.youtube.com/watch?v=zWqLYby99EU