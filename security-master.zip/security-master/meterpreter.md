# Meterpreter

Meterpreter is metasploits own shell. It runs in memory so it leaves no trace on disk. And it has a few other stealthy features. It also communicated encrypted. So that is good. 

There are several versions of meterpreter. And what it can do depends on the OS and how it was executed. A php-meterpreter shell will have certain functionality, and a binary-meterpreter-shell will have other. The same between different OS:s. Do know what commands you have access to on your meterpreter-shell you can run `?` in meterpreter and it will output all the commands that you have access to.