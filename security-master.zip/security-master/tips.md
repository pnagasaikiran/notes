# Tips

- Whenever you find a service always make sure you know if it is vulnerable or not. Be it ssh, ftp, server, front-end library or framework. And unpatched ssh-client can count as a bug in a bug bounty program.

For example, se this bug report:
https://hackerone.com/reports/139940