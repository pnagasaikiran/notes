# XML External Entity Attack

https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing