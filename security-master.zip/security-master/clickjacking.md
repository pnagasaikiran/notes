# Clickjacking



# References

HackerOne issues
https://hackerone.com/reports/109373