# Firewalls

## Terminology

Let's start with some terminology. We often hear the words **egress filtering** and **ingress** in connection to talk about firewalls and routers.


**Egress filtering**

This basically means that we are filtering outgoing traffic. So egress filtering ensures that malicious, or just prohibited, traffic is not allowed to leave the network. Of course egress filtering then is the enemy of the hacker. 

