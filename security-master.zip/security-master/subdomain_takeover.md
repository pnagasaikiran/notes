# Subdomain Takeover

This is a really cool attack.

First you looks for all subdomains. Sometimes a company has forgotten about a subdomain. Like and old support system called `support.example.com`. And then the support-system that points to that domain gets removed. That means that we could start a service for support, and like it to that domain. And thereby controlling the domain.



HackerOne reports

https://hackerone.com/reports/114134
https://hackerone.com/reports/109699

https://blog.getwhitehats.com/being-a-developer-can-be-a-stressful-job-following-the-request-of-your-employer-creating-website-e96af56e51c3#.t3tqd5s0n
http://yassineaboukir.com/blog/neglected-dns-records-exploited-to-takeover-subdomains/
https://labs.detectify.com/2014/10/21/hostile-subdomain-takeover-using-herokugithubdesk-more/