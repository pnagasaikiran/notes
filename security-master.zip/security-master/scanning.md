# Recon and Information Gathering Phase

So once you have decided on a target you want to start your recon-process. 

The recon-phase is usually divided up into two phases.

1. Passive information gathering / OSINT 
   This is when you check out stuff like:
 - Web information
 - Email Harvesting
 - Whois enumeration

2. Active information gathering

This is when you start scanning the target with your different tools.

