# Metasploit


Well metasploit is of course way to big to treat in a simple book like this. But I am going to give it a shot anyways. Because what he hell, it is not like this book has a word-limit.

