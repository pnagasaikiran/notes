## Identifying Technology Stack



* Job openings



