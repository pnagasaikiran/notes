# Web-services

Vulnerabilities on the web can cause many different times of hacks. You can use it to get access to another users data. Or it can work as a step towards remote code execution.

A great way to see real examples of specific attack you can check hackerone.com like this through google: 

```
site:hackerone.com clickjacking
```

## Visit OWASP top 10

This chapter is largely based on the OWASP top 10 vulnerabilities. So if you want a better explanation just check out their website.
https://www.owasp.org/index.php/Top_10_2013-Top_10