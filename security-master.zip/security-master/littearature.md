# Literature


## Zines


**2600: The Hacker Quarterly**

https://www.2600.com/

**Go null yourself**

http://web.textfiles.com/ezines/GONULLYOURSELF/gonullyourself1.txt

**Hacking with Kali**

https://archive.org/stream/HackingWithKali/Hacking%20with%20Kali_djvu.txt


## Books

**Hacking - The Art of Exploitation**

**Pentesting - A Hands-On Introduction to Hacking by Georgia Weidman**