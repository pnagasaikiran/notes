# Vulnerabilities

There are a number of different common vulnerabilities that are found in binaries. In this chapter we are going to discuss some of the common ones.

The main idea behind these exploits is to corrupt the memory allocation to inject arbitrary code that gets executed by the program. 

