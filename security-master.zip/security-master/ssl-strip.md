# SSL-strip

If the user you are intercepting is communicating over HTTPS your interception will trigger an alert very time a user tried to enter a https-page. This is not what we want. In order do bypass this we can remove the ssl-part of every request. It is less likely that the user will notice a change from HTTPS to HTTP in the url-bar.


## Reference
Penteration Testing - A hands on introduction to hacking. Page 174
