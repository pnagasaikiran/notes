# Windows

Whether you like it or not Windows is the most common OS for desktop users in the world. So for a pentester it is fundamental to understand the ins and outs of it.

So this chapter will contain some basics about Windows and windows networks.

We will also look a bit at PowerShell and of course the good old CMD. 