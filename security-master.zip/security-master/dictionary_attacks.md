# Dictionary Attacks

## Burp suite
Intercept the login request
Rightclick - Send to intruder
