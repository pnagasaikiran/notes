# Attacking the user

In this section we focus on vectors that attack the user. These kinds of vulnerabilities seems to be popular with in bug bounties.