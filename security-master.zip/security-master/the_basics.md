# The Basics

In this chapter we will look at some basics, good stuff to know before we begin. The basics of how Windows work and the basics of Linux. 

It is also pretty useful to know how to cook together a simple bash-script, so we are going to look at some really simple bash operations.

And a little bit about PowerShell, and the windows command line. PowerShell is becomming more and more important as a tool for hackers. So this chapters will probably keep expanding.

Python is also the hackers friend, so I have included a little bit about some basic operations with python.

Transferring files is also pretty fundamental. It could be placed in the post-exploit chapter, but I think it fits better here since it is necessary for any work between different machines.

Vim is another thing that you can't live without. So can use it as your main editor for writing and editing code or notes, but even if you don't use it as your main editor you still need to know the basics of it in order to be able to edit files on your hacked machines.  

