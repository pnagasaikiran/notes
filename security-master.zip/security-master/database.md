# Database

Working with the database that is connected to metasploit is great.


```
workspace
workspace -a nameOfNewWorkspace #Add
workspace -d nameOfNewWorkspace #Delete
```


```
hosts
```

```
services
```