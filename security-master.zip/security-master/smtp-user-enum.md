# smtp-user-enum

You can find more about this is Server-site-vulnerabilities/List of common ports/Port 25
https://bobloblaw.gitbooks.io/security/content/list_of_common_ports.html
