# Text/content-injection


Relevant hackerone reports:
https://hackerone.com/reports/145853

https://www.owasp.org/index.php/Content_Spoofing
